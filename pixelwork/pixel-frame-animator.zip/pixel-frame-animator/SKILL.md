---
name: pixel-frame-animator
description: 用 Python + Pillow 手工绘制像素风格角色的帧动画（行走/攻击/跳跃/奔跑/闪避等），输出逐帧 PNG、精灵表、atlas 与 SHA 校验。This skill should be used when the user asks for pixel-art character animation, sprite frames, 帧动画, 像素小人/像素角色动作, walking/attack/jump cycles, or converting a character image into pixel animation frames. Also applies when another agent needs to generate pixel sprite frames from a reference character.
agent_created: true
---

# 像素帧动画制作

## Overview

用「程序化点阵绘制」产出像素角色帧动画：Python 脚本在 64×64 网格上以调色板索引逐像素绘制人物，
通过姿态参数生成多帧，导出逐帧 PNG / 精灵表 / atlas / SHA 校验。

不是 AI 生图、不是扩散模型、不是切图——每一帧都是同一套绘制函数在不同姿态参数下真实重绘的结果。

## 何时使用

- 用户要「把这个角色做成像素帧动画 / 行走攻击跳跃奔跑闪避」
- 用户要「游戏精灵图 / sprite sheet / 逐帧动作」
- 用户给了参考角色图，要求做像素版动作帧
- 任何 Agent 需要批量产出有限调色板的角色动作帧

## 运行环境

只需 **Pillow**（12.3.0）。优先使用隔离环境：
`C:\Users\PC-7020\.workbuddy\binaries\python\envs\default\Scripts\python.exe`

若 Pillow 缺失，向用户说明并请求许可后再安装到该 venv，**不要**全局 pip install、不要擅自下载。

## 工作流

### 第 1 步：确认需求（参数不齐先问一次）

| 项 | 选项 | 默认 |
|---|---|---|
| 画布 | 16 / 32 / 64 | **64**（能容纳武器和服饰细节） |
| 每动作帧数 | 2–3 / **4** / 6 | 4 |
| 武器/道具 | 保留完整 / 简化 / 不带 | 保留 |
| 动作清单 | 行走/攻击/跳跃/奔跑/闪避… | 按用户要求 |

参考图的角色若要转成像素版：按「原创像素演绎」处理，说明不承诺与原图逐像素一致。

### 第 2 步：复制模板并改造

```bash
cp <skill>/scripts/frame_anim_template.py  <工作目录>/<角色名>.py
```

改造三处（脚本内已用 `---- 1/2/3 ----` 注释标好分区）：

1. `PALETTE` —— 索引 0 必须透明，总数 ≤ 16
2. 四个绘制函数 `draw_back / draw_body / draw_weapon / draw_fx`
   —— 用 `rect / ell / seg / d.polygon` 画，`fill` 填**调色板索引**而非 RGB
3. `ACTIONS` —— 每个动作一组姿态参数，一帧一组

进阶写法（大型武器、特效状态机、多层摆动）参考 `assets/example_character.py` 中的弓箭手实现。

### 第 3 步：运行出包

```bash
python <角色名>.py  <新的输出目录>          # 目录必须不存在，绝不覆盖旧成果
python <skill>/scripts/make_gif.py <输出目录>/frames preview.gif 120   # 可选：GIF 预览
```

输出：`frames/*.png`、`sprite-sheet.png`、`contact-sheet-8x.png`、`atlas.json`、`palette.json`、`manifest.sha256`。

### 第 4 步：目检（不可跳过）

**必须真实打开 `contact-sheet-8x.png` 逐帧查看**，判断四项：
轮廓可辨识 / 帧间姿态有真实差异 / 部位与配色一致 / 未被画布截断。

脚本只校验「帧不重复、非空白」，**机械通过 ≠ 好看**。不合格就调参数重画，不要靠话术宣称完成。

### 第 5 步：交付

给出输出目录 + 文件清单 + 建议帧率（行走 8fps、攻击 10fps、奔跑 12fps 参考值）。
明确说明：这是静态帧集合，不含播放器或游戏引擎接入。

## 核心方法：姿态参数化

不要为每帧重写绘制代码。同一套函数吃不同参数：

| 参数 | 含义 | 典型取值 |
|---|---|---|
| `dy` | 整体上下位移（正=下沉） | 行走 ±1，跳跃 -7~+3 |
| `lean` | 身体前倾像素 | 奔跑 2，闪避 4–9 |
| `legs` | 0并立 1左前 2右前 3收腿 4大跨 | 按动作枚举 |
| `swing` | 披风/头发摆动像素 | -3~+3 |
| `arm` | 手坐标 `(x,y)`，`None`=垂放 | 攻击帧指向武器 |
| `fx` | 特效名 | `'slash'` / `'dust'` / `None` |

各动作的设计要点（重心节奏、爆点帧、残影处理）见 `references/pixel-conventions.md` 第四节。

## 硬约束速查

1. 调色板 ≤ 16 色，索引 0 = 透明，其余 alpha = 255
2. 画布 16/32/64 正方形
3. 纯硬边，放大一律 NEAREST，禁止抗锯齿/模糊/渐变
4. 主体有深色描边（索引 1）
5. 头/腰/脚锚点固定，姿态只做相对偏移，否则帧间抖动
6. 每帧渲染结果必须不同（脚本会拦截重复帧）
7. 四边留 1–2 px 余量，不截断

完整规范 + 常见翻车点（描边吃色 / 手悬空 / 动作看不出来）见 `references/pixel-conventions.md`。

## 修订已有动画

1. 读旧工程的 `atlas.json` 与 `manifest.sha256`，核对完整性
2. 改姿态参数或绘制函数，**输出到新目录**，保留旧包
3. 若只改某部位（如眼睛），定位该部位的精确矩形，不要全画布重画
4. 全局改色属于破坏性变更，须用户明确同意，并列出每个索引的变化与影响区域
5. 新旧联系表对照，解释改动与边界

## Resources

### scripts/
- `frame_anim_template.py` —— 自包含模板（配置 → 绘制 → 渲染 → 导出 → 帧差异校验），可直接复制改造
- `make_gif.py` —— 把帧序列合成 GIF 预览（仅供预览，不做正式交付）

### references/
- `pixel-conventions.md` —— 硬约束、分层约定、各动作设计要点、常见翻车点、交付物清单

### assets/
- `example_character.py` —— 进阶示例：持大型武器的弓箭手（四层绘制 + 弓弦状态机 + 特效层）
