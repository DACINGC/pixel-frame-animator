# -*- coding: utf-8 -*-
"""
进阶示例：手持大型武器的角色（弓箭手）
—— 展示「四层独立绘制 + 武器状态机 + 特效层」怎么写。

用法：把下面 PALETTE / draw_back / draw_body / draw_weapon / draw_fx / ACTIONS
      替换进 scripts/frame_anim_template.py 的对应部分即可运行（OUT 用命令行参数指定）。

本文件是「写法参考」，不是可直接执行的脚本。
"""
from PIL import ImageDraw

SIZE = 64

PALETTE = [
    (0, 0, 0, 0),          # 0 透明
    (40, 34, 54, 255),     # 1 描边
    (56, 120, 214, 255),   # 2 主蓝（帽子/裙）
    (120, 186, 255, 255),  # 3 浅蓝（高光/箭羽）
    (30, 66, 140, 255),    # 4 深蓝（袖/鞋）
    (246, 249, 253, 255),  # 5 白（云纹/裙摆）
    (255, 222, 196, 255),  # 6 皮肤
    (236, 182, 148, 255),  # 7 皮肤暗
    (242, 132, 52, 255),   # 8 橙发
    (255, 182, 96, 255),   # 9 橙发亮
    (214, 48, 62, 255),    # 10 红宝石
    (48, 46, 58, 255),     # 11 黑袜
    (232, 182, 84, 255),   # 12 金（弓饰/箭）
    (98, 200, 96, 255),    # 13 绿瞳（小面积，绝不加 outline）
    (130, 232, 255, 255),  # 14 特效青
    (86, 90, 110, 255),    # 15 残影灰蓝
]

# ---- 姿态参数扩展：draw_px 弓弦拉开量、arrow 箭的状态、blink 眨眼 ----
# pose 需自行扩展字典字段，例：
#   pose(dy=0, lean=1, legs=2, swing=0, arm=(22,32), fx=None, draw_px=22, arrow='nock')

def draw_back(d, p):
    """脑后长发：swing 控制发梢左右摆动"""
    y, sw = p['dy'], p['swing']
    d.polygon([(24, 14 + y), (41, 14 + y), (45, 24 + y), (44 + sw, 32 + y),
               (41 + sw, 38 + y), (42 + sw, 41 + y), (37 + sw, 38 + y),
               (33 + sw, 41 + y), (28 + sw, 38 + y), (24 + sw, 40 + y),
               (21 + sw, 34 + y), (20, 24 + y)], fill=8, outline=1)
    d.line([(38, 20 + y), (41 + sw, 32 + y)], fill=9, width=1)
    d.line([(25, 20 + y), (22 + sw, 32 + y)], fill=9, width=1)

def draw_body(d, p):
    """头（帽子+绿瞳）+ 躯干 + 四肢。注意绿瞳不加 outline，否则会被描边吃成黑块"""
    y, x = p['dy'], p['lean']
    d.polygon([(27 + x, 26 + y), (38 + x, 26 + y), (41 + x, 36 + y), (24 + x, 36 + y)],
              fill=2, outline=1)
    d.rectangle((30 + x, 27 + y, 35 + x, 32 + y), fill=5)
    d.line([(27 + x, 33 + y), (38 + x, 33 + y)], fill=12, width=1)     # 金腰带
    d.polygon([(25 + x, 35 + y), (40 + x, 35 + y), (43 + x, 41 + y), (22 + x, 41 + y)],
              fill=5, outline=1)                                        # 裙摆
    # 头
    d.ellipse((25, 12 + y, 40, 27 + y), fill=6, outline=1)
    d.polygon([(25, 14 + y), (40, 14 + y), (40, 18 + y), (37, 17 + y), (35, 20 + y),
               (33, 17 + y), (31, 19 + y), (29, 17 + y), (27, 20 + y), (25, 17 + y)], fill=8)
    if not p.get('blink'):
        d.rectangle((27, 20 + y, 28, 21 + y), fill=13)                  # 绿瞳，无描边
        d.rectangle((33, 20 + y, 34, 21 + y), fill=13)
        d.line([(27, 22 + y), (28, 22 + y)], fill=1, width=1)
        d.line([(33, 22 + y), (34, 22 + y)], fill=1, width=1)
    d.chord((22, 4 + y, 43, 17 + y), 180, 360, fill=2, outline=1)       # 帽子
    d.rectangle((22, 12 + y, 43, 15 + y), fill=4, outline=1)
    d.rectangle((30, 6 + y, 34, 9 + y), fill=10, outline=1)             # 红宝石
    # 持弓臂：抓握点必须落在弓实体上（GRIP 与弓弧中段对齐）
    grip = (9 + x, 32)
    d.line([(28 + x, 30 + y), (grip[0] + 2, grip[1] + y)], fill=6, width=3)
    if p['arm'] is None:
        d.line([(37 + x, 30 + y), (39 + x, 36 + y)], fill=6, width=3)
    else:
        d.line([(37 + x, 30 + y), (p['arm'][0] - 1, p['arm'][1] + y)], fill=6, width=3)

def draw_weapon(d, p):
    """弓：arc 画弓臂 + 云纹弓梢 + 弓弦（draw_px 控制拉开）+ 箭（arrow 状态机）"""
    import math
    y = p['dy']
    bbox = (6, 10 + y, 30, 54 + y)
    d.arc(bbox, 115, 245, fill=1, width=5)
    d.arc(bbox, 115, 245, fill=2, width=3)
    cx, cy = 18, 32 + y
    rx, ry = 12, 22
    def tip(deg):
        a = math.radians(deg)
        return (round(cx + rx * math.cos(a)), round(cy - ry * math.sin(a)))
    top, bot = tip(115), tip(245)
    d.ellipse((top[0] - 3, top[1] - 3, top[0] + 2, top[1] + 2), fill=5, outline=1)
    d.ellipse((bot[0] - 3, bot[1] - 3, bot[0] + 2, bot[1] + 2), fill=5, outline=1)
    sx = top[0]
    if p.get('draw_px') is None:                                        # 弦松弛
        d.line([(sx, top[1]), (sx, bot[1])], fill=5, width=1)
    else:                                                               # 弦拉开
        d.line([(sx, top[1]), (p['draw_px'], 32 + y)], fill=5, width=1)
        d.line([(p['draw_px'], 32 + y), (sx, bot[1])], fill=5, width=1)
    if p.get('arrow') == 'nock':                                        # 搭箭
        ax = p.get('draw_px') or sx
        d.line([(6, 32 + y), (ax, 32 + y)], fill=12, width=1)
        d.polygon([(3, 32 + y), (8, 29 + y), (8, 35 + y)], fill=3, outline=1)
    elif p.get('arrow') == 'fly':                                       # 箭已射出
        d.line([(-2, 32 + y), (10, 32 + y)], fill=12, width=1)
        d.polygon([(10, 32 + y), (5, 29 + y), (5, 35 + y)], fill=14, outline=1)

def draw_fx(d, p):
    kind, y = p['fx'], p['dy']
    if kind == 'release':                                               # 放箭闪光
        d.ellipse((0, 28 + y, 8, 36 + y), fill=14)
    elif kind == 'slash':                                               # 月牙斩击波
        d.arc((2, 24 + y, 26, 44 + y), 120, 240, fill=14, width=2)
        d.arc((4, 26 + y, 24, 42 + y), 130, 230, fill=5, width=1)
    elif kind == 'streak':                                              # 闪避残影
        d.line([(12, 28 + y), (26, 28 + y)], fill=15, width=1)
        d.line([(10, 40 + y), (26, 40 + y)], fill=15, width=1)
    elif kind == 'dust':                                                # 落地尘土
        d.ellipse((44, 54 + y, 50, 58 + y), fill=5, outline=1)

# ---- 动作表（姿态参数化：改动作只改这里）----
ACTIONS = {
    'walk':   [{'dy': 1, 'lean': 0, 'legs': 1, 'swing': 1},
               {'dy': 0, 'lean': 0, 'legs': 0, 'swing': 0},
               {'dy': 1, 'lean': 0, 'legs': 2, 'swing': -1, 'blink': True},
               {'dy': 0, 'lean': 0, 'legs': 0, 'swing': 0}],
    'attack': [{'arrow': 'nock'},
               {'arrow': 'nock', 'draw_px': 22, 'arm': (22, 32), 'lean': 1},
               {'arrow': 'nock', 'draw_px': 26, 'arm': (26, 32), 'lean': 2, 'blink': True},
               {'arrow': 'fly', 'lean': 1, 'arm': (24, 31), 'blink': True, 'fx': 'slash'}],
    'jump':   [{'dy': 3, 'legs': 3, 'swing': 2},
               {'dy': -3, 'legs': 0, 'swing': -2},
               {'dy': -7, 'legs': 3, 'swing': -2},
               {'dy': -2, 'legs': 0, 'swing': 1, 'fx': 'dust'}],
    'run':    [{'dy': 0, 'lean': 2, 'legs': 4, 'swing': -1},
               {'dy': -1, 'lean': 2, 'legs': 2, 'swing': -2},
               {'dy': 0, 'lean': 2, 'legs': 4, 'swing': 1},
               {'dy': -1, 'lean': 2, 'legs': 1, 'swing': 2}],
    'dodge':  [{'dy': 2, 'lean': 2, 'legs': 3, 'swing': 2, 'fx': 'streak'},
               {'dy': 4, 'lean': 6, 'legs': 3, 'swing': 3, 'blink': True, 'fx': 'streak'},
               {'dy': 2, 'lean': 9, 'legs': 3, 'swing': 2, 'blink': True, 'fx': 'streak'},
               {'dy': 0, 'lean': 4, 'legs': 2, 'swing': 1, 'fx': 'dust'}],
}
