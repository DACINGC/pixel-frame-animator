# -*- coding: utf-8 -*-
"""把已导出的帧序列合成 GIF 动图预览，方便人工判断动作是否连贯。

用法：
    python make_gif.py <frames目录> [输出.gif] [每帧毫秒]

例：
    python make_gif.py ./demo/frames walk.gif 120
    python make_gif.py ./demo/frames            # 默认 preview.gif / 120ms

说明：GIF 仅用于预览，正式交付仍是逐帧 PNG + 精灵表（GIF 不支持半透明边缘与调色板工程）。
"""
import sys
from pathlib import Path
from PIL import Image

def natural(name):
    # 按 action_0 / action_1 ... 的数字排序
    stem = Path(name).stem
    tail = stem.rsplit('_', 1)[-1]
    return (stem.rsplit('_', 1)[0], int(tail) if tail.isdigit() else 0)

def main():
    if len(sys.argv) < 2:
        raise SystemExit('用法: python make_gif.py <frames目录> [输出.gif] [每帧毫秒]')
    src = Path(sys.argv[1])
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.parent / 'preview.gif'
    dur = int(sys.argv[3]) if len(sys.argv) > 3 else 120
    files = sorted([p for p in src.glob('*.png')], key=lambda p: natural(p.name))
    if not files:
        raise SystemExit(f'目录里没有 PNG：{src}')
    frames = [Image.open(p).convert('RGBA') for p in files]
    base = frames[0]
    bg = Image.new('RGBA', base.size, (24, 26, 32, 255))      # 深色底，便于看清透明边缘
    frames = [Image.alpha_composite(bg, f).convert('P', palette=Image.ADAPTIVE) for f in frames]
    frames[0].save(out, save_all=True, append_images=frames[1:], duration=dur, loop=0,
                   disposal=2, optimize=False)
    print(f'OK -> {out}  帧数={len(frames)}  间隔={dur}ms')

if __name__ == '__main__':
    main()
